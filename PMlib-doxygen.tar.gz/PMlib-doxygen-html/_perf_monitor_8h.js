var _perf_monitor_8h =
[
    [ "PerfMonitor", "classpm__lib_1_1_perf_monitor.html", "classpm__lib_1_1_perf_monitor" ],
    [ "PM_TIMING__", "_perf_monitor_8h.html#aee9c6a027a2cb7302172098ecce17ce9", null ],
    [ "PM_TIMING_DETAIL__", "_perf_monitor_8h.html#afc63c153573addb042a94547fc23d98f", null ]
];