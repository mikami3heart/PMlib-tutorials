var pmlib__papi_8h =
[
    [ "hwpc_group_chooser", "structhwpc__group__chooser.html", "structhwpc__group__chooser" ],
    [ "pmlib_papi_chooser", "structpmlib__papi__chooser.html", "structpmlib__papi__chooser" ],
    [ "hwpc_output_group", "pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240", [
      [ "I_elapse", "pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240ac3d4e1bdf6cde81dc38749899820c2c4", null ],
      [ "I_flops", "pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240a59599c29cc41c8805a41833514f74996", null ],
      [ "I_vector", "pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240a734d841e175de92bc79829540db69b7d", null ],
      [ "I_bandwidth", "pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240a53214a281dc0cbfe08b9daa321937c1c", null ],
      [ "I_cache", "pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240a2e2d816d08c973ab3ac4cbcf287d24c2", null ],
      [ "I_cycle", "pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240ac1481a93fa635c1abefef5f29a6898a5", null ],
      [ "Max_hwpc_output_group", "pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240ae714149f95d7b55e8271ec53d86fac2c", null ]
    ] ],
    [ "Max_chooser_events", "pmlib__papi_8h.html#a8e695cbd091c7d913e6fe6c43a470b09", null ]
];