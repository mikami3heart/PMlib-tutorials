var annotated =
[
    [ "pm_lib", null, [
      [ "PerfMonitor", "classpm__lib_1_1_perf_monitor.html", "classpm__lib_1_1_perf_monitor" ],
      [ "PerfWatch", "classpm__lib_1_1_perf_watch.html", "classpm__lib_1_1_perf_watch" ]
    ] ],
    [ "hwpc_group_chooser", "structhwpc__group__chooser.html", "structhwpc__group__chooser" ],
    [ "pmlib_papi_chooser", "structpmlib__papi__chooser.html", "structpmlib__papi__chooser" ]
];