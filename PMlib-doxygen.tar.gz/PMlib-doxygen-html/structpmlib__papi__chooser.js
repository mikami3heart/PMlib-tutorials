var structpmlib__papi__chooser =
[
    [ "accumu", "structpmlib__papi__chooser.html#ad5fb66125f7532af663077f9d0cab253", null ],
    [ "events", "structpmlib__papi__chooser.html#a75dd890897beb16d68780ad2eaf5bef9", null ],
    [ "num_events", "structpmlib__papi__chooser.html#a9bcbf866f9acfb2840a859925690508e", null ],
    [ "num_sorted", "structpmlib__papi__chooser.html#a192079a0c138678ee29d61623feeb536", null ],
    [ "s_name", "structpmlib__papi__chooser.html#a621d845e86b46c05b3f0f7cb99a01220", null ],
    [ "s_sorted", "structpmlib__papi__chooser.html#a2c2e11d1b84e1237129a580b0c688056", null ],
    [ "v_sorted", "structpmlib__papi__chooser.html#a0a4f5df8d9ffc573cf9fa798fa27f03c", null ],
    [ "values", "structpmlib__papi__chooser.html#a36b16b40d23d503c95bc24886d46851d", null ]
];