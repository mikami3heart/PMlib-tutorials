var searchData=
[
  ['flops',['flops',['../classpm__lib_1_1_perf_watch.html#ad1544b0ae7e96b766b136451d22028e6',1,'pm_lib::PerfWatch']]]
];
