var indexSectionsWithContent =
{
  0: "aceghikmnprstu~",
  1: "hp",
  2: "p",
  3: "agikpsu~",
  4: "egimnprt",
  5: "t",
  6: "c",
  7: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros"
};

