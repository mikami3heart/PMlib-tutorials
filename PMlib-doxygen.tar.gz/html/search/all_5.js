var searchData=
[
  ['initialize',['initialize',['../classpm__lib_1_1_perf_monitor.html#afc8316db8c1a571e7febfd04a08ec347',1,'pm_lib::PerfMonitor']]],
  ['initializehwpc',['initializeHWPC',['../classpm__lib_1_1_perf_watch.html#ae8b2b5560b306600a9df7f771c13f0c1',1,'pm_lib::PerfWatch']]],
  ['is_5fmpi_5fenabled',['is_MPI_enabled',['../classpm__lib_1_1_perf_monitor.html#a168bcf6ed677dedd70bf3236c0ec9ab1',1,'pm_lib::PerfMonitor']]],
  ['is_5fopenmp_5fenabled',['is_OpenMP_enabled',['../classpm__lib_1_1_perf_monitor.html#a84f2331da4059b653b9fb9af597bb392',1,'pm_lib::PerfMonitor']]],
  ['is_5fpapi_5fenabled',['is_PAPI_enabled',['../classpm__lib_1_1_perf_monitor.html#a18b7198c16efe8a4b21dab415417ba88',1,'pm_lib::PerfMonitor']]]
];
