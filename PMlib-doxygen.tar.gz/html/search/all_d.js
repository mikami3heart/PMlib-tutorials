var searchData=
[
  ['unitflop',['unitFlop',['../classpm__lib_1_1_perf_watch.html#a3614c15d0ced82dc4758932760984475',1,'pm_lib::PerfWatch']]]
];
