var searchData=
[
  ['gather',['gather',['../classpm__lib_1_1_perf_monitor.html#aad4f1f2abcd7e19f210a0f56cac07a9e',1,'pm_lib::PerfMonitor::gather()'],['../classpm__lib_1_1_perf_watch.html#aa7dce440cc937ba2c320d034eba46b5d',1,'pm_lib::PerfWatch::gather()']]],
  ['gatherhwpc',['gatherHWPC',['../classpm__lib_1_1_perf_watch.html#a72ca05cca0f529fb07824b5f2472a20a',1,'pm_lib::PerfWatch']]],
  ['get_5ftypecalc',['get_typeCalc',['../classpm__lib_1_1_perf_watch.html#adec519cbf14b3467346ec63955485b4b',1,'pm_lib::PerfWatch']]],
  ['gettime',['getTime',['../classpm__lib_1_1_perf_watch.html#a8357ed34d810504762e6760430e13757',1,'pm_lib::PerfWatch']]],
  ['getversioninfo',['getVersionInfo',['../classpm__lib_1_1_perf_monitor.html#af3934406d020413731f6624c35038bc8',1,'pm_lib::PerfMonitor']]]
];
