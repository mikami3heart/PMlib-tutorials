var searchData=
[
  ['add_5fperf_5flabel',['add_perf_label',['../classpm__lib_1_1_perf_monitor.html#a8e8f4ca786ae011ba9b58eab3fc1d957',1,'pm_lib::PerfMonitor']]]
];
