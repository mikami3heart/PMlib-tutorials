var structhwpc__group__chooser =
[
    [ "i_platform", "structhwpc__group__chooser.html#ae6dd73503ccbac67e9efbc4222ceba38", null ],
    [ "index", "structhwpc__group__chooser.html#a37e2e7ad818c9abc78c6661029dd62c8", null ],
    [ "number", "structhwpc__group__chooser.html#afe96a3ecef46750d289f1fd16a2f6e8d", null ],
    [ "platform", "structhwpc__group__chooser.html#a1af1a25fe4f16a04eec1a8536ec1b6ea", null ]
];