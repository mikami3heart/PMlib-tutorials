var annotated_dup =
[
    [ "pm_lib", "namespacepm__lib.html", "namespacepm__lib" ],
    [ "hwpc_group_chooser", "structhwpc__group__chooser.html", "structhwpc__group__chooser" ],
    [ "pmlib_papi_chooser", "structpmlib__papi__chooser.html", "structpmlib__papi__chooser" ]
];