var searchData=
[
  ['num_5fevents',['num_events',['../structpmlib__papi__chooser.html#a9bcbf866f9acfb2840a859925690508e',1,'pmlib_papi_chooser']]],
  ['num_5fprocess',['num_process',['../classpm__lib_1_1_perf_monitor.html#a528ebb86303b3242333d89a188e9b6b9',1,'pm_lib::PerfMonitor::num_process()'],['../classpm__lib_1_1_perf_watch.html#ab7106c85bb0fd97dfd170a4caa745bc3',1,'pm_lib::PerfWatch::num_process()']]],
  ['num_5fsorted',['num_sorted',['../structpmlib__papi__chooser.html#a192079a0c138678ee29d61623feeb536',1,'pmlib_papi_chooser']]],
  ['num_5fthreads',['num_threads',['../classpm__lib_1_1_perf_monitor.html#a7117dc0a3fc9f5499ce1387bd2b6f4a2',1,'pm_lib::PerfMonitor']]],
  ['number',['number',['../structhwpc__group__chooser.html#afe96a3ecef46750d289f1fd16a2f6e8d',1,'hwpc_group_chooser']]]
];
