var searchData=
[
  ['i_5fbandwidth',['I_bandwidth',['../pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240a53214a281dc0cbfe08b9daa321937c1c',1,'pmlib_papi.h']]],
  ['i_5fcache',['I_cache',['../pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240a2e2d816d08c973ab3ac4cbcf287d24c2',1,'pmlib_papi.h']]],
  ['i_5fcycle',['I_cycle',['../pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240ac1481a93fa635c1abefef5f29a6898a5',1,'pmlib_papi.h']]],
  ['i_5felapse',['I_elapse',['../pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240ac3d4e1bdf6cde81dc38749899820c2c4',1,'pmlib_papi.h']]],
  ['i_5fflops',['I_flops',['../pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240a59599c29cc41c8805a41833514f74996',1,'pmlib_papi.h']]],
  ['i_5fplatform',['i_platform',['../structhwpc__group__chooser.html#ae6dd73503ccbac67e9efbc4222ceba38',1,'hwpc_group_chooser']]],
  ['i_5fvector',['I_vector',['../pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240a734d841e175de92bc79829540db69b7d',1,'pmlib_papi.h']]],
  ['index',['index',['../structhwpc__group__chooser.html#a37e2e7ad818c9abc78c6661029dd62c8',1,'hwpc_group_chooser']]],
  ['initialize',['initialize',['../classpm__lib_1_1_perf_monitor.html#afc8316db8c1a571e7febfd04a08ec347',1,'pm_lib::PerfMonitor']]],
  ['initializehwpc',['initializeHWPC',['../classpm__lib_1_1_perf_watch.html#ae8b2b5560b306600a9df7f771c13f0c1',1,'pm_lib::PerfWatch']]],
  ['initializeotf',['initializeOTF',['../classpm__lib_1_1_perf_watch.html#aaeae4be4b6823341ab0426f732893e37',1,'pm_lib::PerfWatch']]],
  ['is_5fmpi_5fenabled',['is_MPI_enabled',['../classpm__lib_1_1_perf_monitor.html#a168bcf6ed677dedd70bf3236c0ec9ab1',1,'pm_lib::PerfMonitor']]],
  ['is_5fopenmp_5fenabled',['is_OpenMP_enabled',['../classpm__lib_1_1_perf_monitor.html#a84f2331da4059b653b9fb9af597bb392',1,'pm_lib::PerfMonitor']]],
  ['is_5fotf_5fenabled',['is_OTF_enabled',['../classpm__lib_1_1_perf_monitor.html#ae8323df842a25c0d4775ee1f339ae36d',1,'pm_lib::PerfMonitor']]],
  ['is_5fpapi_5fenabled',['is_PAPI_enabled',['../classpm__lib_1_1_perf_monitor.html#a18b7198c16efe8a4b21dab415417ba88',1,'pm_lib::PerfMonitor']]]
];
