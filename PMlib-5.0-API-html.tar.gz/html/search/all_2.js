var searchData=
[
  ['events',['events',['../structpmlib__papi__chooser.html#a75dd890897beb16d68780ad2eaf5bef9',1,'pmlib_papi_chooser']]],
  ['exclusivestarted',['ExclusiveStarted',['../classpm__lib_1_1_perf_watch.html#a650b43e1889d945f7c7bf1b845fa5940',1,'pm_lib::PerfWatch']]]
];
