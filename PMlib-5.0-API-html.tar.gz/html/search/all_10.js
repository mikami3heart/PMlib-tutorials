var searchData=
[
  ['v_5fsorted',['v_sorted',['../structpmlib__papi__chooser.html#a0a4f5df8d9ffc573cf9fa798fa27f03c',1,'pmlib_papi_chooser']]],
  ['values',['values',['../structpmlib__papi__chooser.html#a36b16b40d23d503c95bc24886d46851d',1,'pmlib_papi_chooser']]]
];
