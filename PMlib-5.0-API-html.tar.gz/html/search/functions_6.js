var searchData=
[
  ['mpi_5fallgather',['MPI_Allgather',['../namespacepm__lib.html#a7044594f9efdf9b51db338d5ef9b7d3e',1,'pm_lib']]],
  ['mpi_5fallreduce',['MPI_Allreduce',['../namespacepm__lib.html#acaeb4d326ebb377c4940d2b9ba0a037c',1,'pm_lib']]],
  ['mpi_5fbarrier',['MPI_Barrier',['../namespacepm__lib.html#ab43c78145d69de9339e809b9733e573f',1,'pm_lib']]],
  ['mpi_5fcomm_5fgroup',['MPI_Comm_group',['../namespacepm__lib.html#aeccfb7124e783bce444f11b85fb58360',1,'pm_lib']]],
  ['mpi_5fcomm_5frank',['MPI_Comm_rank',['../namespacepm__lib.html#a191b262f13f69013b12bff79aade405a',1,'pm_lib']]],
  ['mpi_5fcomm_5fsize',['MPI_Comm_size',['../namespacepm__lib.html#a8cd1651e94670d2fc061840fa3266b85',1,'pm_lib']]],
  ['mpi_5ffinalize',['MPI_Finalize',['../namespacepm__lib.html#af66de12da47f7d402e07a5e1f876af99',1,'pm_lib']]],
  ['mpi_5fgather',['MPI_Gather',['../namespacepm__lib.html#a42190e7b4301792ee7f7535e7ea357f5',1,'pm_lib']]],
  ['mpi_5fgroup_5fincl',['MPI_Group_incl',['../namespacepm__lib.html#aa364833518e817ffb26d5356b7c066f4',1,'pm_lib']]],
  ['mpi_5fgroup_5frank',['MPI_Group_rank',['../namespacepm__lib.html#ad4f40227ba8fce736ae8149204cb1289',1,'pm_lib']]],
  ['mpi_5fgroup_5fsize',['MPI_Group_size',['../namespacepm__lib.html#a99f3ac18967e898de76bd1d04c5888b5',1,'pm_lib']]],
  ['mpi_5finit',['MPI_Init',['../namespacepm__lib.html#acb73f651f4c55c0f1c10919685033ba7',1,'pm_lib']]]
];
