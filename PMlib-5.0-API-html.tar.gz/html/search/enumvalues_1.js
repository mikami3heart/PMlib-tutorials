var searchData=
[
  ['i_5fbandwidth',['I_bandwidth',['../pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240a53214a281dc0cbfe08b9daa321937c1c',1,'pmlib_papi.h']]],
  ['i_5fcache',['I_cache',['../pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240a2e2d816d08c973ab3ac4cbcf287d24c2',1,'pmlib_papi.h']]],
  ['i_5fcycle',['I_cycle',['../pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240ac1481a93fa635c1abefef5f29a6898a5',1,'pmlib_papi.h']]],
  ['i_5felapse',['I_elapse',['../pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240ac3d4e1bdf6cde81dc38749899820c2c4',1,'pmlib_papi.h']]],
  ['i_5fflops',['I_flops',['../pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240a59599c29cc41c8805a41833514f74996',1,'pmlib_papi.h']]],
  ['i_5fvector',['I_vector',['../pmlib__papi_8h.html#abdb17f8d24ad37cccffeec73a5058240a734d841e175de92bc79829540db69b7d',1,'pmlib_papi.h']]]
];
