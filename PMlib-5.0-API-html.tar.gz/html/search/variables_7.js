var searchData=
[
  ['parallel_5fmode',['parallel_mode',['../classpm__lib_1_1_perf_monitor.html#a25130ae08d405d7a5c35c2ab94a46b1f',1,'pm_lib::PerfMonitor']]],
  ['platform',['platform',['../structhwpc__group__chooser.html#a1af1a25fe4f16a04eec1a8536ec1b6ea',1,'hwpc_group_chooser']]]
];
