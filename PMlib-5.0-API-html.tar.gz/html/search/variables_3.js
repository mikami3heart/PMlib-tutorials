var searchData=
[
  ['i_5fplatform',['i_platform',['../structhwpc__group__chooser.html#ae6dd73503ccbac67e9efbc4222ceba38',1,'hwpc_group_chooser']]],
  ['index',['index',['../structhwpc__group__chooser.html#a37e2e7ad818c9abc78c6661029dd62c8',1,'hwpc_group_chooser']]],
  ['is_5fmpi_5fenabled',['is_MPI_enabled',['../classpm__lib_1_1_perf_monitor.html#a168bcf6ed677dedd70bf3236c0ec9ab1',1,'pm_lib::PerfMonitor']]],
  ['is_5fopenmp_5fenabled',['is_OpenMP_enabled',['../classpm__lib_1_1_perf_monitor.html#a84f2331da4059b653b9fb9af597bb392',1,'pm_lib::PerfMonitor']]],
  ['is_5fotf_5fenabled',['is_OTF_enabled',['../classpm__lib_1_1_perf_monitor.html#ae8323df842a25c0d4775ee1f339ae36d',1,'pm_lib::PerfMonitor']]],
  ['is_5fpapi_5fenabled',['is_PAPI_enabled',['../classpm__lib_1_1_perf_monitor.html#a18b7198c16efe8a4b21dab415417ba88',1,'pm_lib::PerfMonitor']]]
];
