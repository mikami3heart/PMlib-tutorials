var searchData=
[
  ['unitflop',['unitFlop',['../classpm__lib_1_1_perf_watch.html#a4c6dc9cb995a66097fee66a0455e017a',1,'pm_lib::PerfWatch']]]
];
