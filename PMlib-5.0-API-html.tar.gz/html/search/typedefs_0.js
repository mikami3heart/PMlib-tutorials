var searchData=
[
  ['mpi_5fcomm',['MPI_Comm',['../namespacepm__lib.html#a68a299be092c30cbeb9d31979c55feff',1,'pm_lib']]],
  ['mpi_5fdatatype',['MPI_Datatype',['../namespacepm__lib.html#aa400e3c5db6da2a625085c9b30899188',1,'pm_lib']]],
  ['mpi_5fgroup',['MPI_Group',['../namespacepm__lib.html#abc7aa2fefc8e4e07996c5bfd6ec9793d',1,'pm_lib']]],
  ['mpi_5fop',['MPI_Op',['../namespacepm__lib.html#ac63b8c1f9b1147accf145ab27f6bc49e',1,'pm_lib']]]
];
