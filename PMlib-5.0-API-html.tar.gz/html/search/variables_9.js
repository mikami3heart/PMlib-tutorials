var searchData=
[
  ['s_5fname',['s_name',['../structpmlib__papi__chooser.html#a621d845e86b46c05b3f0f7cb99a01220',1,'pmlib_papi_chooser']]],
  ['s_5fsorted',['s_sorted',['../structpmlib__papi__chooser.html#a2c2e11d1b84e1237129a580b0c688056',1,'pmlib_papi_chooser']]]
];
