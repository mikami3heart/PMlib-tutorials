var searchData=
[
  ['check_5fall_5fperf_5flabel',['check_all_perf_label',['../classpm__lib_1_1_perf_monitor.html#aae4fa644baab0cb759d7f71929eea41d',1,'pm_lib::PerfMonitor']]],
  ['countpapibyte',['countPapiByte',['../classpm__lib_1_1_perf_watch.html#afd739953333e24dc3133cf3084d361cf',1,'pm_lib::PerfWatch']]],
  ['countpapiflop',['countPapiFlop',['../classpm__lib_1_1_perf_watch.html#ab8d38d99522bf65b8d8f6daef5ad584c',1,'pm_lib::PerfWatch']]],
  ['createpapicounterlist',['createPapiCounterList',['../classpm__lib_1_1_perf_watch.html#a9a27c996f019d4e3a7984eb9074e49f0',1,'pm_lib::PerfWatch']]]
];
