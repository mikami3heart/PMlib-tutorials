var searchData=
[
  ['initialize',['initialize',['../classpm__lib_1_1_perf_monitor.html#afc8316db8c1a571e7febfd04a08ec347',1,'pm_lib::PerfMonitor']]],
  ['initializehwpc',['initializeHWPC',['../classpm__lib_1_1_perf_watch.html#ae8b2b5560b306600a9df7f771c13f0c1',1,'pm_lib::PerfWatch']]],
  ['initializeotf',['initializeOTF',['../classpm__lib_1_1_perf_watch.html#aaeae4be4b6823341ab0426f732893e37',1,'pm_lib::PerfWatch']]]
];
