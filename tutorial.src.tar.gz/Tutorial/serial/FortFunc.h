/*
 *  FortFunc.h
 *  kernel_test
 *
 *  Created by keno on 11/12/05.
 *  Copyright 2011-2014 IIS, UT & AICS, RIKEN. All rights reserved.
 *
 */

#ifndef _FORTRAN_FUNC_H_
#define _FORTRAN_FUNC_H_

#include "realtype.h"

extern "C" {
  
  void bc_ (int* sz,
            int* g,
            REAL_TYPE* p,
            REAL_TYPE* dh);

  void jacobi_ (REAL_TYPE* p,
                int* sz,
                int* g,
                REAL_TYPE* omg,
                REAL_TYPE* b,
                double* res,
                REAL_TYPE* wk2,
                double* flop);
  
  void psor_ (REAL_TYPE* p,
              int* sz,
              int* g,
              REAL_TYPE* omg,
              REAL_TYPE* b,
              double* res,
              double* flop);
  
  void src_dirichlet_ (REAL_TYPE* b,
                       int* sz,
                       int* g,
                       REAL_TYPE* dh);
}

#endif // _FORTRAN_FUNC_H_
