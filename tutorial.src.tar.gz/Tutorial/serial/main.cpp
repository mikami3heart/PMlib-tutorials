/*
 *  main.cpp
 *  kernel_test
 *
 *  Created by keno on 11/12/05.
 *  Copyright 2011-2014 IIS, UT & AICS, RIKEN. All rights reserved.
 *
 */

#include <iostream>
#include <math.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "omp.h"
#include "kernel_def.h"
#include "FortFunc.h"
#include "realtype.h"


// PMlibの登録ラベル個数
#define PM_NUM_MAX 50

// ラベル長さ
#define TM_LABEL_MAX 24


using namespace std;
using namespace pm_lib;


int order_of_PM_key;      ///< PMlib用の登録番号カウンタ < PM_NUM_MAX



REAL_TYPE* allocate_REAL(size_t size, REAL_TYPE init)
{
	REAL_TYPE *var;
  
	if ( !(var=new REAL_TYPE[size]) ) {
    printf("Failed to allocate memory %d (MB)", (unsigned)size/(1024*1024));
    assert(0);
	}
	for (size_t i=0; i<size; i++) *(var+i) = init;
	return var;
}


// #################################################################
/**
 * @brief タイミング測定区間にラベルを与えるラッパー
 * @param [in] label     ラベル
 * @param [in] type      測定対象タイプ(COMM or CALC)
 * @param [in] exclusive 排他測定フラグ(ディフォルトtrue)
 */
void set_label(PerfMonitor* pm, const string label, PerfMonitor::Type type, bool exclusive)
{
  // 登録個数のチェック
  order_of_PM_key++;
  
  if ( order_of_PM_key > PM_NUM_MAX )
  {
    printf("\tThe number of labels for Performance monitor goes over limit.\n");
    exit(0);
  }
  
  // 文字数がTM_LABEL_MAX-1を超えるものはカット
  if ( strlen(label.c_str()) > TM_LABEL_MAX-1 )
  {
    printf("\tWarning: Length of timing label must be less than %d\n", TM_LABEL_MAX-1);
  }
  
  // Performance Monitorへの登録
  pm->setProperties(label, type, exclusive);
}


//@brief タイミング測定区間にラベルを与える
void set_timing_label(PerfMonitor* pm)
{
  // 非排他, 計算
  //	set_label(pm, "Jacobi",           PerfMonitor::CALC, false);
  //	set_label(pm, "PointSOR",         PerfMonitor::CALC, false);
  
  set_label(pm, "BoundaryCondition",PerfMonitor::AUTO, true);
  set_label(pm, "Norm_max",         PerfMonitor::AUTO, true);
  
  set_label(pm, "Jacobi_kernel",    PerfMonitor::AUTO, true);
  set_label(pm, "Sor_kernel",       PerfMonitor::AUTO, true);
}


int main (int argc, char * const argv[]) {
  
  if (argc != 4)
  {
    printf("\tUsage: kernel size linear_solver Iteration\n");
    printf("\t$ ./kernel 128 [jacobi | sor] 1000\n");
    return 0;
  }
  
  int dim = atoi(argv[1]);
  printf("\tarray size = %d^3\n", dim);
  
  int gc = 1; // guide cell
  int sz[3] = {dim, dim, dim};
  int size = (dim+2*gc) * (dim+2*gc) * (dim+2*gc);
  
  REAL_TYPE* p   = NULL;    // pressure
  REAL_TYPE* src0= NULL;    // source term 0
  REAL_TYPE* wrk = NULL;    // work array
  
  
  // allocate array
  p   = allocate_REAL(size, 0.0);
  src0= allocate_REAL(size, 0.0);
  
  // constant
  double eps = 1.0e-5;    // convergence criteria
  REAL_TYPE ac1 = 1.1;    // acceleration coef. for SOR
  REAL_TYPE ac2 = 0.8;    // acceleration coef. for jacobi relaxation
  REAL_TYPE coef;
  
  // grid width
  REAL_TYPE dh  = 1.0/(REAL_TYPE)(dim+1);
  
  
  // type
  int ls_type=0;
  char* q = argv[2];
  printf("\tLinear solver = %s\n", q);
  
  char fname[20];
  memset(fname, 0, sizeof(char)*20);
  
  
  if      ( !strcasecmp(q, "jacobi") ) {
    ls_type = JACOBI;
    strcpy(fname, "jacobi.txt");
    wrk = allocate_REAL(size, 0.0);
  }
  
  else if ( !strcasecmp(q, "sor") ) {
    ls_type = SOR;
    strcpy(fname, "sor.txt");
  }
  
  else{
    printf("Invalid solver\n");
    exit(0);
  }

  int ItrMax = atoi(argv[3]);
  
  
  // Apply BC
  bc_(sz, &gc, p, &dh);

  
  // history title
  FILE* fp;
  if ( !(fp=fopen(fname, "w")) )
  {
    printf("\tSorry, can't open file.\n");
    assert(0);
  }
  
  fprintf(fp,"Column_Data_00\n");
  fprintf(fp, "Itration          Residual\n");

  // timing
  int num_thread  = omp_get_max_threads();
  
  
  PerfMonitor PM;
  PM.initialize( PM_NUM_MAX );
  PM.setRankInfo( 0 );
  PM.setParallelMode("OpenMP", num_thread, 0);
  set_timing_label(&PM);

  
  // source term
  src_dirichlet_(src0, sz, &gc, &dh);
  

  int loop;
  double flop_count;
  
  // scheme branch
  switch (ls_type) {
      
    case JACOBI:
      //	TIMING_start(&PM, "Jacobi");
      
      for (loop=1; loop<=ItrMax; loop++)
      {
        double res = 0.0;
        
        // 反復処理
        TIMING_start(&PM, "Jacobi_kernel");
        flop_count = 0.0;
        jacobi_(p, sz, &gc, &coef, src0, &res, wrk, &flop_count);
        TIMING_stop(&PM, "Jacobi_kernel", flop_count);
        
        
        // 境界条件
        TIMING_start(&PM, "BoundaryCondition");
        bc_(sz, &gc, p, &dh);
        TIMING_stop(&PM, "BoundaryCondition");
        
        
        // 収束判定
        double res2 = sqrt(res);
        fprintf(fp, "%8d %13.6e\n", loop, res2);
        
        if ( res2 < eps ) break;
        
      }
      //	TIMING_stop(&PM, "Jacobi");
      break;
      
      
    case SOR:
      //	TIMING_start(&PM, "PointSOR");
      
      for (loop=1; loop<=ItrMax; loop++)
      {
        double res = 0.0;
        
        // 反復処理
        TIMING_start(&PM, "Sor_kernel");
        flop_count = 0.0;
        psor_(p, sz, &gc, &coef, src0, &res, &flop_count);
        TIMING_stop(&PM, "Sor_kernel", flop_count);
        
        
        // 境界条件
        TIMING_start(&PM, "BoundaryCondition");
        bc_(sz, &gc, p, &dh);
        TIMING_stop(&PM, "BoundaryCondition");
        
        
        // 収束判定
        double res2 = sqrt(res);
        fprintf(fp, "%8d %13.6e\n", loop, res2);
        
        if ( res2 < eps ) break;
        
      }

      //	TIMING_stop(&PM, "PointSOR");
      break;

    default:
      assert(0);
      break;
  }

  
  if ( !fp ) fclose(fp);
  

  // profiling
  if ( !(fp=fopen("data-profiling.txt", "w")) )
  {
    printf("\tSorry, can't open 'profiling.txt' file. Write failed.\n");
    assert(0);
  }
  
  // 測定結果の集計(gathreメソッドは全ノードで呼ぶこと)
  PM.gather();
  
  // 結果出力(排他測定のみ)
  printf("\n===============================\n");
  PM.print(stdout, "hoge", "foo");
  PM.print(fp, "hoge", "foo");
  
  PM.printDetail(stdout);
  PM.printDetail(fp);
  
  if ( !fp ) fclose(fp);
  
  
  return 0;
}
