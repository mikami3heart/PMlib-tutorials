#ifndef _REALTYPE_DEF_H_
#define _REALTYPE_DEF_H_
/*
 *  realtype.h
 *  kernel_test
 *
 *  Created by keno on 11/12/05.
 *  Copyright 2011-2014 IIS, UT & AICS, RIKEN. All rights reserved.
 *
 */

/** 実数型の指定
 * - デフォルトでは、REAL_TYPE=float
 * - コンパイル時オプション-D_REAL_IS_DOUBLE_を付与することで
 *   REAL_TYPE=doubleになる
 */

#ifdef _REAL_IS_DOUBLE_
#define REAL_TYPE double
#else

#define REAL_TYPE float
#endif

#endif
