#include <omp.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string>
#include <PerfMonitor.h>				// PMlib
using namespace pm_lib;					// PMlib
PerfMonitor PM;							// PMlib

#define MATSIZE 1000
int nsize=MATSIZE;
struct {
	int nsize;
	float a2[MATSIZE][MATSIZE];
	float b2[MATSIZE][MATSIZE];
	float c2[MATSIZE][MATSIZE];
} matrix;
void set_array();
void subkerel();
double my_timer_(void);

int main (int argc, char *argv[])
{
    int my_id=0, num_threads=1, npes=1;
	char parallel_mode[] = "OpenMP";
	double flop_count, dsize;

	matrix.nsize = nsize;
	dsize = (double)nsize;

    PM.initialize();
    PM.setParallelMode(parallel_mode, num_threads, npes);
    PM.setRankInfo(my_id);
    PM.setProperties("check_OpenMP", PerfMonitor::CALC);

	set_array();
	flop_count=pow (dsize, 3.0)*4.0;

	int loop=3;
	for (int i=1; i<=loop; i++){
		PM.start("check_OpenMP");
		subkerel();
		PM.stop ("check_OpenMP", flop_count, 1);
	}
	PM.gather();
	PM.print(stdout, "London", "Mr. Bean");
	PM.printDetail(stdout);

	return 0;
}


void set_array()
{
int i, j, nsize;
nsize = matrix.nsize;
#pragma omp parallel
#pragma omp for
	for (i=0; i<nsize; i++){
	for (j=0; j<nsize; j++){
	matrix.a2[i][j] = sin((float)j/(float)nsize);
	matrix.b2[i][j] = cos((float)j/(float)nsize);
	matrix.c2[i][j] = 0.0;
	}
	}
}

void subkerel()
{
int i, j, k, nsize;
float c1,c2,c3;
nsize = matrix.nsize;
#pragma omp parallel
#pragma omp for
	for (i=0; i<nsize; i++){
	for (j=0; j<nsize; j++){
		c1=0.0;
		for (k=0; k<nsize; k++){
		c2=matrix.a2[i][k] * matrix.a2[j][k];
		c3=matrix.b2[i][k] * matrix.b2[j][k];
		c1=c1 + c2+c3;
		}
		matrix.c2[i][j] = matrix.c2[i][j] + c1/(float)nsize;
	}
	}
}

