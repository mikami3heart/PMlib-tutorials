#!/bin/bash
#BSUB -J CHECK
#BSUB -o CHECK.%J
#BSUB -n 1
#BSUB -R "span[ptile=1]"
#	#BSUB -R "span[ptile=16]"
#BSUB -x
module load intel impi papi/intel 
#	module load intel impi papi/intel pmlib/intel
#	module load ${HOME}/local_module/pmlib/intel
module load ${HOME}/local_module/pmlib/v3.0.3
module list
set -x
date
hostname

#	SRC_DIR=/home/ra000004/mikami/pmlib/Tutorial/serial
SRC_DIR=/home/ra000004/mikami/pmlib/Tutorial/example
cd $SRC_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
make -f Makefile.serial clean
make -f Makefile.serial
ls -go
./pmlib_test.ex
exit

WKDIR=/media/dali/data1/mikami/check_tutorial
mkdir -p $WKDIR
cd $WKDIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
rm $WKDIR/*
cp $SRC_DIR/kernel.ex .

NPROCS=1
export OMP_NUM_THREADS=8
./kernel.ex 128 sor 10
./kernel.ex 128 jacobi 10

