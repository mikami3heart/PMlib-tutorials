#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string>

#define MATSIZE 1000
int nsize;
struct {
	int nsize;
	float a2[MATSIZE][MATSIZE];
	float b2[MATSIZE][MATSIZE];
	float c2[MATSIZE][MATSIZE];
} matrix;
void set_array();
void subkerel();
double my_timer_(void);
int my_id, npes, num_threads;

int main (int argc, char *argv[])
{
	double flop_count, bandwidth_count, dsize;
	double t1, t2;
	int i, j, loop, num_threads;

	my_id=0;
	npes=1;
	num_threads  = 1;

	nsize=MATSIZE;
	matrix.nsize = nsize;
	set_array();

	dsize = (double)nsize;
	flop_count=pow (dsize, 3.0)*4.0;
	if(my_id == 0) {
		fprintf(stderr, "<main> npes=%d, num_threads=%d\n", npes, num_threads);
		fprintf(stderr, "one kernel() has %15.0f f.ops \n\n", flop_count);
	}

	loop=3;
	for (i=1; i<=loop; i++){
		t1=my_timer_();
		subkerel();
		t2=my_timer_();
		if(my_id == 0) {
			fprintf(stderr, "loop %d finished in %f seconds\n", i,t2-t1);
		}
	}


	if(my_id == 0) {
		fprintf(stderr, "total of %15.0f f.ops were executed.\n", flop_count*npes*loop);
	}
	return 0;
}

// general timer routine 
// remark that the timer resolution of gettimeofday is only millisecond order
#include        <sys/time.h>
double my_timer_()
{
	struct timeval s_val;
	gettimeofday(&s_val,0);
	return ((double) s_val.tv_sec + 0.000001*s_val.tv_usec);
}



void set_array()
{
int i, j, nsize;
nsize = matrix.nsize;
#pragma omp parallel
#pragma omp for
	for (i=0; i<nsize; i++){
	for (j=0; j<nsize; j++){
	matrix.a2[i][j] = sin((float)j/(float)nsize);
	matrix.b2[i][j] = cos((float)j/(float)nsize);
	matrix.c2[i][j] = 0.0;
	}
	}
}

void subkerel()
{
int i, j, k, nsize;
float c1,c2,c3;
nsize = matrix.nsize;
#pragma omp parallel
#pragma omp for
	for (i=0; i<nsize; i++){
	for (j=0; j<nsize; j++){
		c1=0.0;
		for (k=0; k<nsize; k++){
		c2=matrix.a2[i][k] * matrix.a2[j][k];
		c3=matrix.b2[i][k] * matrix.b2[j][k];
		c1=c1 + c2+c3;
		}
		matrix.c2[i][j] = matrix.c2[i][j] + c1/(float)nsize;
	}
	}
}

