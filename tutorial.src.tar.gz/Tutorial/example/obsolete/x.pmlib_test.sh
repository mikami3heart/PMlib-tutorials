#!/bin/bash
#BSUB -J CHECK
#BSUB -o CHECK.%J
#BSUB -n 1
#BSUB -R "span[ptile=1]"
#	#BSUB -R "span[ptile=16]"
#BSUB -x
module load intel impi papi/intel 
module load ${HOME}/local_module/pmlib/v3.0.3
module list
set -x
date
hostname

SRC_DIR=/home/ra000004/mikami/pmlib/Tutorial/example
cd $SRC_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
make -f Makefile.serial clean
make -f Makefile.serial
ls -go
./pmlib_test.ex

make -f Makefile.openmp clean
make -f Makefile.openmp
ls -go
./pmlib_test.ex

