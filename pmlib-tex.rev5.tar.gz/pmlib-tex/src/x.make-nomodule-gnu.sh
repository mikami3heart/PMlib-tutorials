#!/bin/bash
set -x
#	AUTOCONF_PATH=${HOME}/autoconf/local_autoconf/bin
#	AUTOMAKE_PATH=${HOME}/autoconf/local_automake/bin
#	export PATH=${AUTOCONF_PATH}:${AUTOMAKE_PATH}:${PATH}

export 	FC=gfortran 
export 	CC=gcc 
export 	CXX=g++ 
export 	HYDRA_BOOTSTRAP=ssh 
export 	HYDRA_BOOTSTRAP_EXEC=/usr/bin/ssh 
OPENMPI_DIR=/usr/local/openmpi/openmpi-1.8.7-gnu 
PAPI_ROOT=/usr/local/papi/papi-5.3.2/gnu 
LDFLAGS="-L${PAPI_ROOT}/lib -lpapi -lpfm"
INCLUDES="-I{PAPI_ROOT}/include"

MPI_DIR=${OPENMPI_DIR}
PAPI_DIR=${PAPI_ROOT}

export  PATH=${OPENMPI_DIR}/bin:${PAPI_ROOT}/bin:${PATH}
export  LD_LIBRARY_PATH=${OPENMPI_DIR}/lib:${PAPI_ROOT}/lib:${LD_LIBRARY_PATH}

INSTALL_DIR=${HOME}/pmlib/install_gnu
SRC_DIR=${HOME}/pmlib/PMlib
BUILD_DIR=${SRC_DIR}/BUILD_DIR
cd $BUILD_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
make distclean >/dev/null 2>&1

CFLAGS="-O3 -fopenmp ${INCLUDES}"
FCFLAGS="-cpp -O3 -fopenmp ${LDFLAGS}"
CXXFLAGS="-O3 -fopenmp ${LDFLAGS}"

../configure \
	CXX=mpicxx CC=mpicc FC=mpif90 \
    CFLAGS="${CFLAGS}" CXXFLAGS="${CXXFLAGS}" FCFLAGS="${FCFLAGS}" \
    -prefix=${INSTALL_DIR} \
	--with-comp=GNU \
    --with-ompi=${MPI_DIR} \
    --with-papi=${PAPI_DIR} \
	--with-example=yes \

make
exit

make install
exit

if [ $? != 0 ] ; then echo '@@@ installation error @@@'; exit; fi

NPROCS=2
export OMP_NUM_THREADS=2
mpirun -np ${NPROCS} example/test1/test1

sleep 2
mpirun -np ${NPROCS} example/test2/test2

sleep 2
export HWPC_CHOOSER=FLOPS
mpirun -np ${NPROCS} example/test3/test3
sleep 2
mpirun -np ${NPROCS} example/test4/test4
sleep 2

#	export HWPC_CHOOSER=FLOPS           # OK
#   export HWPC_CHOOSER=FLOPS,VECTOR    # OK
#   export HWPC_CHOOSER=BANDWIDTH           # OK
#   export HWPC_CHOOSER=BANDWIDTH,CACHE # OK
#   export HWPC_CHOOSER=BANDWIDTH,CYCLE,INSTRUCTION # OK
#	export HWPC_CHOOSER=FLOPS,BANDWIDTH	# NG

