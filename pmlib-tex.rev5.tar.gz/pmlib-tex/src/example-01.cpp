#include <PerfMonitor.h>
using namespace pm_lib;
PerfMonitor PM;
int main (int argc, char *argv[])
{
	PM.initialize();
	PM.setProperties("Block-1", PerfMonitor::CALC);
	PM.setProperties("Block-2", PerfMonitor::COMM);

	PM.start("Block-1");
	compute1(&flop_count);
	PM.stop ("Block-1", flop_count);

	PM.start("Block-2");
	compute2(&bandwidth_count);
	PM.stop ("Block-2", bandwidth_count);

	PM.gather();
	PM.print(stdout);
	PM.printDetail(stdout);
	return 0;
}

