#!/bin/bash
# [1] Intel version
module load intel impi papi/intel
module list
set -x
AUTOCONF_PATH=${HOME}/autoconf/local_autoconf/bin
AUTOMAKE_PATH=${HOME}/autoconf/local_automake/bin
export PATH=${AUTOCONF_PATH}:${AUTOMAKE_PATH}:${PATH}

MPI_DIR=${I_MPI_ROOT}

INSTALL_DIR=${HOME}/pmlib/install_impi
SRC_DIR=${HOME}/pmlib/PMlib
BUILD_DIR=${SRC_DIR}/BUILD_DIR
cd $BUILD_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi

CFLAGS="-std=c99 -openmp"
FCFLAGS="-fpp -openmp "
CXXFLAGS="-openmp "

make distclean >/dev/null 2>&1

../configure \
	CXX=mpicxx CC=mpicc FC=mpif90 \
	CFLAGS="${CFLAGS}" CXXFLAGS="${CXXFLAGS}" FCFLAGS="${FCFLAGS}" \
	-prefix=${INSTALL_DIR} \
	--with-impi=${MPI_DIR} \
	--with-comp=INTEL \
    --with-papi=${PAPI_DIR} \
	--with-example=yes >/dev/null 2>&1

make
make install
if [ $? != 0 ] ; then echo '@@@ installation error @@@'; exit; fi

NPROCS=8
export OMP_NUM_THREADS=2
mpirun -np ${NPROCS} example/test1/test1
sleep 2
export HWPC_CHOOSER=FLOPS
mpirun -np ${NPROCS} example/test1/test1
exit
mpirun -np ${NPROCS} example/test2/test2
sleep 2
mpirun -np ${NPROCS} example/test3/test3
sleep 2
mpirun -np ${NPROCS} example/test4/test4
sleep 2
pwd
