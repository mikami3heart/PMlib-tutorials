#!/bin/bash
# [1] Intel version
module load intel papi/intel
module list
set -x
date
hostname
AUTOCONF_PATH=${HOME}/autoconf/local_autoconf/bin
AUTOMAKE_PATH=${HOME}/autoconf/local_automake/bin
export PATH=${AUTOCONF_PATH}:${AUTOMAKE_PATH}:${PATH}

INSTALL_DIR=${HOME}/pmlib/install_intel
SRC_DIR=${HOME}/pmlib/PMlib
BUILD_DIR=${SRC_DIR}/BUILD_DIR
cd $BUILD_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
make distclean >/dev/null 2>&1

CFLAGS="-openmp "
FCFLAGS="-fpp -openmp "
CXXFLAGS="-openmp "

../configure \
	CXX=icpc CC=icc FC=ifort \
    CFLAGS="${CFLAGS}" CXXFLAGS="${CXXFLAGS}" FCFLAGS="${FCFLAGS}" \
    -prefix=${INSTALL_DIR} \
	--with-comp=GNU \
	--with-example=yes \
    --with-papi=${PAPI_DIR} \
    # >/dev/null 2>&1
    #	--with-papi="none" \

make
sleep 2
#	exit
make install
if [ $? != 0 ] ; then echo '@@@ install error @@@'; exit; fi


example/test1/test1
sleep 2
export HWPC_CHOOSER=FLOPS
example/test2/test2
sleep 2
example/test3/test3	# MPI process group
sleep 2
example/test4/test4	# Fortran MPI

