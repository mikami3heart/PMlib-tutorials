#!/bin/bash
# [1] Intel version
module load gnu openmpi/gnu papi/gnu
module list
set -x
AUTOCONF_PATH=${HOME}/autoconf/local_autoconf/bin
AUTOMAKE_PATH=${HOME}/autoconf/local_automake/bin
export PATH=${AUTOCONF_PATH}:${AUTOMAKE_PATH}:${PATH}

date
hostname

INSTALL_DIR=/usr/local/pmlib/pmlib-4.1.0-gnu

SRC_DIR=${HOME}/pmlib/PMlib
BUILD_DIR=${SRC_DIR}/BUILD_DIR
cd $BUILD_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
make distclean >/dev/null 2>&1

CFLAGS="-fopenmp "
FCFLAGS="-cpp -fopenmp "
CXXFLAGS="-fopenmp "

../configure \
	CXX=g++ CC=gcc FC=gfortran \
    CFLAGS="${CFLAGS}" CXXFLAGS="${CXXFLAGS}" FCFLAGS="${FCFLAGS}" \
    -prefix=${INSTALL_DIR} \
	--with-comp=GNU \
	--with-example=yes \
    --with-papi=${PAPI_DIR} \
    # >/dev/null 2>&1
    #	--with-papi="none" \

make
sleep 2
exit
make install
if [ $? != 0 ] ; then echo '@@@ install error @@@'; exit; fi

example/test1/test1
sleep 2
example/test2/test2
#	sleep 2

