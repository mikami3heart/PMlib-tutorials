#!/bin/bash
#BSUB -J PMLIB-USER
#BSUB -o PMLIB-USER-%J
#BSUB -n 8
#BSUB -R "span[ptile=2]"
#BSUB -x
#	source /usr/share/Modules/init/bash
#	module load gnu openmpi/gnu papi/gnu pmlib/gnu-pmlib-4.0
module load gnu openmpi/gnu papi/gnu pmlib/gnu
module list
set -x
date
hostname

SRC_DIR=${HOME}/pmlib/scripts
#	WKDIR=/home/ra000004/mikami/tmp/wrk_dir/check_pmlib
#	WKDIR=/work/ra000004/mikami/tmp/check_pmlib
WKDIR=/media/dali/data1/mikami/check_pmlib
mkdir -p $WKDIR
cd $WKDIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
rm $WKDIR/*

#   cp $SRC_DIR/main_split_comm.cpp main.cpp
cp $SRC_DIR/main_group_comm.cpp main.cpp
cp $SRC_DIR/sub_kernel.c .
cp $SRC_DIR/sub_copy.c .

CFLAGS="-cpp -fopenmp ${REPORTS}"
INCLUDES="-I${PMLIB_ROOT}/include "
LDFLAGS="-L${PMLIB_ROOT}/lib -lPMmpi -lpapi_ext "
LDFLAGS="${LDFLAGS}  -L/usr/local/papi/papi-5.2.0/gnu/lib -lpapi -lpfm "

mpicxx -c ${CFLAGS} ${INCLUDES} main.cpp
mpicc  -c ${CFLAGS} ${INCLUDES} sub_kernel.c
mpicc  -c ${CFLAGS} ${INCLUDES} sub_copy.c
mpicxx    ${CFLAGS} ${INCLUDES} main.o sub_kernel.o sub_copy.o ${LDFLAGS}


export HWPC_CHOOSER=FLOPS
#	export HWPC_CHOOSER=BANDWIDTH
#	export HWPC_CHOOSER=VECTOR

NPROCS=8
#NPROCS=2
export OMP_NUM_THREADS=2
#	export OMP_NUM_THREADS=8
#	export OMP_NUM_THREADS=16
#	export OMP_NUM_THREADS=1

echo starting main_group_comm
sleep 3
mpirun -np ${NPROCS} ./a.out

