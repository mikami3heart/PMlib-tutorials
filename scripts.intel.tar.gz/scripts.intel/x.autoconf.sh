#!/bin/bash
#	module load intel impi papi/intel
AUTOCONF_PATH=${HOME}/autoconf/local_autoconf/bin
AUTOMAKE_PATH=${HOME}/autoconf/local_automake/bin
export PATH=${AUTOCONF_PATH}:${AUTOMAKE_PATH}:${PATH}

SRC_DIR=${HOME}/pmlib/PMlib
cd $SRC_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi

set -x
#	autoreconf -i
#	
#	exit

aclocal
autoheader
automake -a -c
autoconf

