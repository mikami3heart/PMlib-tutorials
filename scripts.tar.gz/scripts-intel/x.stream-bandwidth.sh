#!/bin/bash
#BSUB -J Bandwidth-O3-OMP8
#BSUB -o Bandwidth-O3-OMP8.%J
#BSUB -n 8
#BSUB -R "span[ptile=1]"
#	#BSUB -R "span[ptile=16]"
#BSUB -x
#	module load intel impi papi/intel pmlib/intel
module load intel impi papi/intel 
#	module load ${HOME}/local_module/pmlib/intel
module load ${HOME}/local_module/pmlib/v3.0.3
module list
set -x
date
hostname
echo INCLUDES=${INCLUDES}
#	exit

SRC_DIR=/home/ra000004/mikami/pmlib/scripts
WKDIR=/media/dali/data1/mikami/check_stream_O3
mkdir -p $WKDIR
cd $WKDIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
rm $WKDIR/*
cp $SRC_DIR/pmlib_stream.cpp main.cpp
cp $SRC_DIR/stream.cpp sub.cpp
#	cp $SRC_DIR/stream.c sub.c

#	CFLAGS="-O0 -openmp ${REPORTS}"
#	CFLAGS="-O1 -openmp ${REPORTS}"
CFLAGS="-O2 -openmp ${REPORTS}"
#	CFLAGS="-O3 -openmp ${REPORTS}"
#	REPORTS="-vec-report -openmp-report"
#	CFLAGS="-O3 -openmp -opt-prefetch=0 ${REPORTS}"
mpicxx -c ${CFLAGS} ${INCLUDES} main.cpp
mpicxx -c ${CFLAGS} ${INCLUDES} sub.cpp
#	mpicc  -c ${CFLAGS} ${INCLUDES} sub.c   
mpicxx    ${CFLAGS} ${INCLUDES}  main.o sub.o ${LDFLAGS}

export HWPC_CHOOSER=BANDWIDTH			# OK
#	export HWPC_CHOOSER=FLOPS			# OK

NPROCS=1
export OMP_NUM_THREADS=8
#	NPROCS=8
#	export OMP_NUM_THREADS=16
#	export KMP_AFFINITY=compact
#	export OMP_NUM_THREADS=1
#	export IDB_HOME=${INTEL_DIR}/debugger
#	mpirun -idb -np ${NPROCS} ./a.out
mpirun -np ${NPROCS} ./a.out

