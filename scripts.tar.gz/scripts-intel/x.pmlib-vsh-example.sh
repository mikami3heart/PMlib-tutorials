#!/bin/bash
# Flat MPI
#BSUB -J PMLIB-EXAMPLE-INTEL
#BSUB -o PMLIB-EXAMPLE-INTEL-%J
#BSUB -n 2
#BSUB -R "span[ptile=1]"
#BSUB -x
#	source /usr/share/Modules/init/bash
#	module load intel impi papi pmlib
module load intel impi papi/intel pmlib/intel
#	module load /home/ra000004/mikami/local_module/pmlib/test-intel
module list
#	set -x
date
hostname

BIN_DIR=${HOME}/pmlib/PMlib-master/example
SRC_DIR=${HOME}/pmlib/scripts
#	WKDIR=/home/ra000004/mikami/tmp/wrk_dir/check_pmlib
WKDIR=/media/dali/data1/mikami/check_pmlib
mkdir -p $WKDIR
cd $WKDIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
rm $WKDIR/*

export HWPC_CHOOSER=FLOPS			# OK
#	export HWPC_CHOOSER=FLOPS,VECTOR	# OK
#	export HWPC_CHOOSER=BANDWIDTH			# OK
#	export HWPC_CHOOSER=BANDWIDTH,CACHE	# OK
#	export HWPC_CHOOSER=BANDWIDTH,CYCLE,INSTRUCTION	# OK

#	set -x
NPROCS=1
export OMP_NUM_THREADS=2
${BIN_DIR}/pmlib_test
#	mpirun -np ${NPROCS} ${BIN_DIR}/pmlib_test
exit

NPROCS=1
for i in 1 2 4 8 16
do
export OMP_NUM_THREADS=${i}
export KMP_AFFINITY=compact
mpirun -np ${NPROCS} ${BIN_DIR}/pmlib_test

done

