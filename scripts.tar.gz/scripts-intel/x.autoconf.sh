#!/bin/bash
#	module load intel impi papi/intel
SRC_DIR=${HOME}/pmlib/PMlib-master
cd $SRC_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi

set -x
aclocal
autoheader
automake -a -c
autoconf

