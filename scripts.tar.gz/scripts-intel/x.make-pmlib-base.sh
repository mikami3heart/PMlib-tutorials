#!/bin/bash
# [1] Intel version
module purge
module load intel impi 
set -x
INSTALLED_DIR=${HOME}/pmlib/install_intel_v303
SRC_DIR=${HOME}/pmlib/PMlib-master
cd $SRC_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi

DISTCLEAN="yes"
if [ ${DISTCLEAN} == "yes" ]
then
make distclean
./configure CXX=icpc CC=icc FC=ifort \
	--with-example=yes \
	-prefix=${INSTALLED_DIR}
fi
make
example/pmlib_test
if [ $? != 0 ] ; then echo '@@@ Make error @@@'; exit; fi
sleep 5
make install


	#	CFLAGS='-std=c99 ' CXXFLAGS='-UUSE_PAPI' \
