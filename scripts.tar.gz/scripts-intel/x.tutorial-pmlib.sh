#!/bin/bash
#BSUB -J CHECK
#BSUB -o CHECK.%J
#BSUB -n 1
#BSUB -R "span[ptile=1]"
#	#BSUB -R "span[ptile=16]"
#BSUB -x
module load intel impi papi/intel
module load ${HOME}/local_module/pmlib/v3.0.3
module list
set -x
date
hostname

SRC_DIR=/home/ra000004/mikami/pmlib/Tutorial/example
cd $SRC_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
rm a.out

# Link with PMlib base version
if [ "yes" = "no" ] ; then
icpc ${PMLIB_INCLUDES} pmlib_test.serial.cpp ${PMLIB_LDFLAGS} -D_PM_WITHOUT_MPI_
time ./a.out
exit
fi

# Link with PMlib OpenMP version
if [ "yes" = "no" ] ; then
icpc -openmp ${PMLIB_INCLUDES} pmlib_test.openmp.cpp ${PMLIB_LDFLAGS} -D_PM_WITHOUT_MPI_
time OMP_NUM_THREADS=1 ./a.out
time OMP_NUM_THREADS=4 ./a.out
exit
fi

if [ "yes" = "no" ] ; then
# Link with PMlib MPI version
mpicxx -openmp ${PMLIB_INCLUDES} pmlib_test.mpixopenmp.cpp ${PMLIB_LDFLAGS}
export OMP_NUM_THREADS=4
time mpirun -np 4 ./a.out
exit
fi


if [ "yes" = "yes" ] ; then
# Link with PMlib MPI version
mpicxx -openmp ${PMLIB_INCLUDES} pmlib_test.mpixopenmp.cpp ${PMLIB_LDFLAGS} ${PAPI_LDFLAGS}
export HWPC_CHOOSER=FLOPS,VECTOR
export OMP_NUM_THREADS=4
time mpirun -np 4 ./a.out
sleep 5
time mpirun -np 8 ./a.out
exit
fi

