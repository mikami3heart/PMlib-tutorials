#!/bin/bash
# [1] Intel version
module load intel 
set -x
INSTALLED_DIR=${HOME}/pmlib/install_intel_v303

SRC_DIR=${HOME}/pmlib/PMlib-master
cd $SRC_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi

make distclean
./configure CXX=icpc CC=icc FC=ifort CFLAGS="-std=c99 -openmp" CXXFLAGS="-openmp" \
	--with-example=yes \
	-prefix=${INSTALLED_DIR}
make
example/pmlib_test
if [ $? != 0 ] ; then echo '@@@ Make error @@@'; exit; fi
sleep 5
make install


