#! /bin/bash
module load intel impi
set -x
hostname
date
SRC_DIR=/home/ra000004/mikami/pmlib/Tutorial/example
cd $SRC_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi


icpc base.serial.cpp
time ./a.out

icpc -openmp base.openmp.cpp
time OMP_NUM_THREADS=4 ./a.out

mpicxx -openmp -D_USE_MPI base.mpixopenmp.cpp
export OMP_NUM_THREADS=4
time mpirun -np 4 ./a.out

mpicxx -openmp -D_USE_MPI base.xtra_printf.cpp
export OMP_NUM_THREADS=4
time mpirun -np 4 ./a.out

rm a.out
