#undef _OPENMP
#include <mpi.h>
#include <stdio.h>
#include <math.h>
#ifdef _OPENMP
#include <omp.h>
#endif
#include <PerfMonitor.h>
using namespace pm_lib;
//	char parallel_mode[] = "Serial";
char parallel_mode[] = "Hybrid";
//	char parallel_mode[] = "OpenMP";
//	char parallel_mode[] = "FlatMPI";
//	extern "C" void stream();
extern void stream();

PerfMonitor PM;
int my_id, npes, num_threads;

int main (int argc, char *argv[])
{

double flop_count;
double tt, t1, t2, t3, t4;
int i, j, loop, num_threads, iret;
float real_time, proc_time, mflops;
long long flpops;

	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &my_id);
	MPI_Comm_size(MPI_COMM_WORLD, &npes);
#ifdef _OPENMP
	num_threads  = omp_get_max_threads();
#else
	num_threads  = 1;
#endif
	if(my_id == 0) fprintf(stderr, "<main> program\n");

	PM.initialize();
	PM.setRankInfo(my_id);


	PM.setProperties("stream_check", PerfMonitor::CALC, false);
	PM.setProperties("sub1_copy", PerfMonitor::CALC);
	PM.setProperties("sub2_scale", PerfMonitor::CALC);
	PM.setProperties("sub3_add", PerfMonitor::CALC);
	PM.setProperties("sub4_triad", PerfMonitor::CALC);

	//	num_threads  = omp_get_max_threads();
	PM.setParallelMode(parallel_mode, num_threads, npes);

	if(my_id == 0) fprintf(stderr, "starting stream benchmark\n");
	PM.start("stream_check");
	t1=MPI_Wtime();
	stream();
	t2=MPI_Wtime();
	MPI_Barrier(MPI_COMM_WORLD);
	PM.stop ("stream_check");
	if(my_id == 0) fprintf(stderr, "stream finished in %f seconds\n", t2-t1);

PM.gather();
//	PM.print(stdout, "abc", "xyz");
//	PM.printDetail(stdout);
PM.print(stderr, "ABC", "xyz");
PM.printDetail(stderr);

MPI_Finalize();
return 0;
}

