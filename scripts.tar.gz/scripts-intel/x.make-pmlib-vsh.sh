#!/bin/bash

# [1] Intel version
# preload modules
module purge
module load intel impi papi/intel
module list
set -x
INSTALLED_DIR=${HOME}/pmlib/install_intel_v303

SRC_DIR=${HOME}/pmlib/PMlib-master
cd $SRC_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi

DISTCLEAN="yes"
USE_MPI="yes"
USE_PAPI="yes"

if [ ${DISTCLEAN} == "yes" ]
then
make distclean
fi

if [ ${USE_MPI} == "yes" ]
then
./configure CXX=mpicxx CC=mpicc FC=mpif90 \
	CFLAGS='-std=c99 -openmp' CXXFLAGS='-openmp ' \
--with-papi=yes \
--with-example=yes \
	-prefix=${INSTALLED_DIR}
else
./configure CXX=icpc CC=icc FC=ifort \
	CFLAGS='-std=c99 -openmp' CXXFLAGS='-openmp ' \
--with-papi=yes \
--with-example=yes \
	-prefix=${INSTALLED_DIR}
fi

	#	--with-papi=/usr/local/papi/papi-5.3.2/intel --enable-papi=yes \

make
make install # to be done by root

export HWPC_CHOOSER=FLOPS,VECTOR

example/pmlib_test
exit

# [2] GNU version
# First decide the installation path of PMlib
#	INSTALLED_DIR="/usr/local/pmlib/pmlib-2.1.3-gnu"
INSTALLED_DIR=${HOME}/pmlib/install_gnu_v303

# load modules
module purge
module load gnu openmpi/gnu papi/gnu
module list

SRC_DIR=${HOME}/pmlib/PMlib-master
cd $SRC_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi

# configure
./configure CXX=mpicxx CC=mpicc FC=mpif90 \
	CFLAGS='-O3 -fopenmp' CXXFLAGS='-O3 -fopenmp -DUSE_PAPI' \
	with_papi=/usr/local/papi/papi-5.2.0/gnu enable_papi=yes \
	-prefix=${INSTALLED_DIR}

# make and install
make
make install # to be done by root



