#!/bin/bash
#BSUB -J CHECK
#BSUB -o CHECK.%J
#BSUB -n 1
#BSUB -R "span[ptile=1]"
#BSUB -x
module load intel papi/intel 
module load ${HOME}/local_module/pmlib/v3.0.3
module list
set -x
date
hostname

SRC_DIR=/home/ra000004/mikami/pmlib/Tutorial/serial
#	SRC_DIR=/home/ra000004/mikami/pmlib/Tutorial/example
cd $SRC_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
make clean
make
NPROCS=1
export OMP_NUM_THREADS=1
export HWPC_CHOOSER=FLOPS,VECTOR
export HWPC_CHOOSER=BANDWIDTH
#	export HWPC_CHOOSER=NONE

./kernel.ex 128 sor 100
#	./kernel.ex 500 sor 3
exit

make -f Makefile.kernel clean
make -f Makefile.kernel

WKDIR=/media/dali/data1/mikami/check_tutorial
mkdir -p $WKDIR
cd $WKDIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
rm $WKDIR/*
cp $SRC_DIR/kernel.ex .

NPROCS=1
export OMP_NUM_THREADS=1
./kernel.ex 128 sor 1000
#	./kernel.ex 128 jacobi 10

