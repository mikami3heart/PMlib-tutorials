#!/bin/bash
# Flat MPI
#BSUB -J PMLIB-C-FLOPS
#BSUB -o PMLIB-C-FLOPS-%J
#BSUB -n 4
#BSUB -R "span[ptile=1]"
#BSUB -x
#	source /usr/share/Modules/init/bash
module load gnu openmpi/gnu papi/gnu pmlib/gnu
module list
set -x
date
hostname

CFLAGS="-O3 -fopenmp "

SRC_DIR=/home/ra000004/mikami/pmlib/scripts
WKDIR=/home/ra000004/mikami/tmp/wrk_dir/check_pmlib
mkdir -p $WKDIR
cd $WKDIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
rm $WKDIR/*
cp $SRC_DIR/pmlib_main.cpp main.cpp
cp $SRC_DIR/sub_kernel.c sub.c

mpicxx -c ${CFLAGS} ${INCLUDES} main.cpp
mpicc  -c ${CFLAGS} ${INCLUDES} sub.c   
mpicxx    ${CFLAGS} ${INCLUDES}  main.o sub.o ${LDFLAGS}

export HWPC_CHOOSER=FLOPS			# OK
#	export HWPC_CHOOSER=FLOPS,VECTOR	# OK
#	export HWPC_CHOOSER=BANDWIDTH			# OK
#	export HWPC_CHOOSER=BANDWIDTH,CACHE	# OK
#	export HWPC_CHOOSER=BANDWIDTH,CYCLE,INSTRUCTION	# OK

NPROCS=1
export OMP_NUM_THREADS=8
mpirun -np ${NPROCS} ./a.out

