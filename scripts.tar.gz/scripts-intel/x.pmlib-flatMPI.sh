#!/bin/bash
# Flat MPI
#BSUB -J FLATMPI
#BSUB -o FLATMPI-%J
#BSUB -n 4
#BSUB -R "span[ptile=1]"
#BSUB -x
#	source /usr/share/Modules/init/bash
module load intel impi papi pmlib
module list
set -x
date
hostname

REPORTS="-vec-report -openmp-report"
CFLAGS="-O3 ${REPORTS}"

SRC_DIR=/home/ra000004/mikami/pmlib/scripts
WKDIR=/home/ra000004/mikami/tmp/wrk_dir/check_pmlib
mkdir -p $WKDIR
cd $WKDIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
rm $WKDIR/*
cp $SRC_DIR/pmlib_no_openmp.cpp main.cpp
cp $SRC_DIR/sub_kernel.c sub.c

mpicxx -c ${CFLAGS} ${INCLUDES} main.cpp
mpicc  -c ${CFLAGS} ${INCLUDES} sub.c   
mpicxx    -openmp ${CFLAGS} ${INCLUDES}  main.o sub.o ${LDFLAGS}
echo LDFLAGS=$LDFLAGS

export HWPC_CHOOSER=FLOPS			# OK
#	export HWPC_CHOOSER=FLOPS,VECTOR	# OK
#	export HWPC_CHOOSER=BANDWIDTH			# OK
#	export HWPC_CHOOSER=BANDWIDTH,CACHE	# OK
#	export HWPC_CHOOSER=BANDWIDTH,CYCLE,INSTRUCTION	# OK
##NG	export HWPC_CHOOSER=FLOPS,CACHE		# Not Good. Cache counters are Zero
##NG	export HWPC_CHOOSER=FLOPS,BANDWIDTH	# Not Good. Memory counters are Zero

NPROCS=4
#	export OMP_NUM_THREADS=8
mpirun -np ${NPROCS} ./a.out

exit
NPROCS=1
for i in 1 2 4 8 16
do
export OMP_NUM_THREADS=${i}
export KMP_AFFINITY=compact
mpirun -np ${NPROCS} ./a.out
done

