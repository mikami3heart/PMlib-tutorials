#!/bin/bash
source /home/system/Env_base
set -x
date
hostname
/opt/FJSVXosPA/bin/xospastop

INSTALL_DIR=${HOME}/pmlib/install_dir
SRC_DIR=${HOME}/pmlib/PMlib
BUILD_DIR=${SRC_DIR}/BUILD_DIR
cd $BUILD_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi

make distclean 2>&1 >/dev/null

CFLAGS="-std=c99 -Kopenmp,fast -Ntl_notrt"
FCFLAGS="-Cpp -Kopenmp,fast -Ntl_notrt"
CXXFLAGS="-Kopenmp,fast -Ntl_notrt "

if [[ $HOSTNAME =~ fe01p ]]
then
# K login node
../configure CXX=FCCpx CC=fccpx FC=frtpx \
   CXXFLAGS="${CXXFLAGS}" CFLAGS="${CFLAGS}" FCFLAGS="${FCFLAGS}" \
   --with-comp=FJ \
   --host=sparc64-unknown-linux-gnu \
   --with-papi=yes \
   --with-example=yes \
   --prefix=${INSTALL_DIR}

else
# compute node
../configure CXX=FCC CC=fcc FC=frt \
   CXXFLAGS="${CXXFLAGS}" CFLAGS="${CFLAGS}" FCFLAGS="${FCFLAGS}" \
   --with-comp=FJ \
   --with-papi=yes \
   --with-example=yes \
   --prefix=${INSTALL_DIR}
fi

make
make install
