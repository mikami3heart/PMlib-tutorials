#!/bin/bash
date
hostname
source /opt/intel/bin/compilervars.sh intel64
set -x
export OPENMPI_DIR=/usr/local/openmpi/openmpi-1.8.7-intel
export PATH=${PATH}:${OPENMPI_DIR}/bin
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${OPENMPI_DIR}/lib

MPI_DIR=${OPENMPI_DIR}
INSTALL_DIR=${HOME}/Desktop/Programming/Perf_tools/AICS-PMlib/install_mac

SRC_DIR=${HOME}/Desktop/Programming/Perf_tools/AICS-PMlib/pmlib/PMlib
#	SRC_DIR=${HOME}/Desktop/Git_Repos/PMlib

BUILD_DIR=${SRC_DIR}/BUILD_DIR
cd $BUILD_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
make distclean >/dev/null 2>&1

CFLAGS="-std=c99 -openmp"
FCFLAGS="-fpp -openmp"
CXXFLAGS="-openmp"

../configure \
	CXX=mpicxx CC=mpicc FC=mpifort \
	CFLAGS="${CFLAGS}" CXXFLAGS="${CXXFLAGS}" FCFLAGS="${FCFLAGS}" \
	--prefix=${INSTALL_DIR} \
	--with-comp=INTEL \
	--with-ompi=${MPI_DIR} \
	--with-papi=none --with-example=yes >/dev/null 2>&1

make

NPROCS=2
export OMP_NUM_THREADS=2
export HWPC_CHOOSER=FLOPS
mpirun -np ${NPROCS} example/test1/test1
sleep 2
mpirun -np ${NPROCS} example/test2/test2
sleep 2
mpirun -np ${NPROCS} example/test3/test3
sleep 2
mpirun -np ${NPROCS} example/test4/test4
sleep 2

make install # may be done by root
if [ $? != 0 ] ; then echo '@@@ installation error @@@'; exit; fi

