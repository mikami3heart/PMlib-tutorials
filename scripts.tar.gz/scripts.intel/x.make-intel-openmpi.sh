#!/bin/bash
# [1] Intel version
module load intel papi/intel
#	module load openmpi/intel 
module load openmpi/intel-1.8.7

module list
set -x
AUTOCONF_PATH=${HOME}/autoconf/local_autoconf/bin
AUTOMAKE_PATH=${HOME}/autoconf/local_automake/bin
export PATH=${AUTOCONF_PATH}:${AUTOMAKE_PATH}:${PATH}

# On vsh (visual cluster), the following exports are done by module command
#	export OPENMPI_DIR=/usr/local/openmpi/openmpi-1.6.5-gnu
#	export OPENMPI_DIR=/usr/local/openmpi/openmpi-1.8.7-intel
#	export PATH=${PATH}:${OPENMPI_DIR}/bin
#	export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${OPENMPI_DIR}/lib

MPI_DIR=${OPENMPI_DIR}
INSTALL_DIR=${HOME}/pmlib/install_openmpi

SRC_DIR=${HOME}/pmlib/PMlib
BUILD_DIR=${SRC_DIR}/BUILD_DIR
cd $BUILD_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi

CFLAGS="-std=c99 -openmp"
FCFLAGS="-fpp -openmp "
CXXFLAGS="-openmp "

make distclean >/dev/null 2>&1

../configure \
	CXX=mpicxx CC=mpicc FC=mpif90 \
	CFLAGS="${CFLAGS}" CXXFLAGS="${CXXFLAGS}" FCFLAGS="${FCFLAGS}" \
	-prefix=${INSTALL_DIR} \
	--with-ompi=${MPI_DIR} \
	--with-comp=GNU \
    --with-papi=${PAPI_DIR} \
	--with-example=yes
	# >/dev/null 2>&1
	#	--with-papi="none" \

make
sleep 2
#	make install
#	if [ $? != 0 ] ; then echo '@@@ installation error @@@'; exit; fi
exit

NPROCS=8
export OMP_NUM_THREADS=2
export HWPC_CHOOSER=FLOPS
mpirun -np ${NPROCS} example/test1/test1
sleep 5
mpirun -np ${NPROCS} example/test2/test2
sleep 5
mpirun -np ${NPROCS} example/test3/test3
sleep 5
mpirun -np ${NPROCS} example/test4/test4
exit

#	export HWPC_CHOOSER=FLOPS           # OK
#   export HWPC_CHOOSER=FLOPS,VECTOR    # OK
#   export HWPC_CHOOSER=BANDWIDTH           # OK
#   export HWPC_CHOOSER=BANDWIDTH,CACHE # OK
#   export HWPC_CHOOSER=BANDWIDTH,CYCLE,INSTRUCTION # OK
#	export HWPC_CHOOSER=FLOPS,BANDWIDTH	# NG

exit

# for serial version

../configure \
	CXX=g++ CC=gcc FC=gfortran \
    CFLAGS="${CFLAGS}" CXXFLAGS="${CXXFLAGS}" \
    FCFLAGS="${FCFLAGS}" \
    -prefix=${INSTALL_DIR} --with-example=yes \
    --with-papi=${PAPI_DIR} \
    >/dev/null 2>&1
    #	--with-papi="none" \

make
make install

if [ $? != 0 ] ; then echo '@@@ installation error @@@'; exit; fi
example/test1/test1
sleep 5
example/test2/test2
sleep 5

