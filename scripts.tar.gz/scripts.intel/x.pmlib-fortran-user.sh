#!/bin/bash
#BSUB -J PMLIB-FORTRAN
#BSUB -o PMLIB-FORTRAN-%J
#BSUB -n 1
#BSUB -R "span[ptile=8]"
#BSUB -x
#	source /usr/share/Modules/init/bash
#	module load intel impi papi pmlib
module load intel impi papi/intel 
module load ${HOME}/local_module/pmlib_local/intel
module list
set -x
date
hostname

CFLAGS="-std=c99 -openmp"
FCFLAGS="-fpp -openmp "
CXXFLAGS="-openmp "

SRC_DIR=${HOME}/pmlib/scripts
WKDIR=/media/dali/data1/mikami/check_pmlib
mkdir -p $WKDIR
cd $WKDIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
rm $WKDIR/*

cp $SRC_DIR/f_main.f90 main.f90

CFLAGS="${CFLAGS} -O3 -openmp ${REPORTS}"
LDFLAGS="${LDFLAGS} -cxxlib"

mpif90 -c ${FCFLAGS} ${INCLUDES} main.f90
mpif90    ${FCFLAGS} ${INCLUDES} main.o ${LDFLAGS}

export HWPC_CHOOSER=FLOPS
#	export HWPC_CHOOSER=VECTOR
#	export HWPC_CHOOSER=BANDWIDTH

NPROCS=2
export OMP_NUM_THREADS=4
mpirun -np ${NPROCS} ./a.out
