#!/bin/bash
# Flat MPI
#BSUB -J PMLIB-USER-MAIN
#BSUB -o PMLIB-USER-MAIN-%J
#BSUB -n 8
#BSUB -R "span[ptile=2]"
#BSUB -x
#	source /usr/share/Modules/init/bash
#	module load intel impi papi pmlib
module load intel impi papi/intel 
#	module load ${HOME}/local_module/pmlib/test
module load ${HOME}/local_module/pmlib/test_mpi
module list
set -x
date
hostname

SRC_DIR=${HOME}/pmlib/scripts
#	WKDIR=/home/ra000004/mikami/tmp/wrk_dir/check_pmlib
#	WKDIR=/work/ra000004/mikami/tmp/check_pmlib
WKDIR=/media/dali/data1/mikami/check_pmlib
mkdir -p $WKDIR
cd $WKDIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
rm $WKDIR/*

cp $SRC_DIR/main_split_comm.cpp main.cpp
#	cp $SRC_DIR/main_group_comm.cpp main.cpp
cp $SRC_DIR/sub_kernel.c .
cp $SRC_DIR/sub_copy.c .
#	CFLAGS="-O3 -openmp ${REPORTS}"
mpicxx -c -openmp ${INCLUDES} main.cpp
mpicc  -c -openmp ${INCLUDES} sub_kernel.c
mpicc  -c -openmp ${INCLUDES} sub_copy.c
mpicxx    -openmp ${INCLUDES} main.o sub_kernel.o sub_copy.o ${LDFLAGS}

#	export HWPC_CHOOSER=FLOPS
#	export HWPC_CHOOSER=VECTOR
#	export HWPC_CHOOSER=BANDWIDTH
export HWPC_CHOOSER=FLOPS

NPROCS=8
#	export OMP_NUM_THREADS=16
#	export OMP_NUM_THREADS=16
export OMP_NUM_THREADS=8

mpirun -np ${NPROCS} ./a.out

