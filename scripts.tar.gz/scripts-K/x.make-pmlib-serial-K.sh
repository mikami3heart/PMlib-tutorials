#!/bin/bash
source /home/system/Env_base
set -x
date
hostname
#	/opt/FJSVXosPA/bin/xospastop

INSTALL_DIR=${HOME}/pmlib/install_dir	# /data/mikami/pmlib
SRC_DIR=${HOME}/pmlib/PMlib-master
cd $SRC_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
make distclean

# Assuming we are on K computer
if [[ $HOSTNAME =~ fe01p ]]
then
# K login node
./configure CXX=FCCpx CC=fccpx FC=frtpx \
   CFLAGS=-Kopenmp,fast  CXXFLAGS='-Kopenmp,fast -DUSE_PAPI -Ntl_notrt' \
   --host=sparc64-unknown-linux-gnu \
   --with-papi=yes \
   --with-example=yes \
   --prefix=${INSTALL_DIR}

else
# compute node
./configure CXX=mpiFCC CC=mpifcc FC=mpifrt CFLAGS=-Kopenmp,fast  \
   CXXFLAGS='-Kopenmp,fast -DUSE_PAPI -Ntl_notrt' \
   --with-papi=yes --with-example=yes \
   --prefix=${INSTALL_DIR}
fi

# on compute node, the flags should set
#	PAPI_LIB="-L/usr/lib64 -lpapi -lpfm "
#	PAPI_INCLUDE=""

make
make install
