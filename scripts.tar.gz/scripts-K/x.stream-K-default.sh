#!/bin/bash
# to be executed on K compute nodes
#PJM -N STREAM-K-PMLIB
#PJM --rsc-list "elapse=0:10:00"
#PJM --rsc-list "node=2"
#PJM --mpi "proc=2"
#PJM --mpi "rank-map-bychip"
#PJM -j
#PJM -S
# stage io files
#PJM --stg-transfiles all
#PJM --mpi "use-rankdir"
#PJM --stgin-basedir "/data/ra000004/a03155/tmp/check_pmlib"
#PJM --stgin "rank=* stream-K-pmlib.ex %r:./"
#	#PJM --stgin-basedir "/home/ra000004/a03155/pmlib/PMlib-master/example"
#	#PJM --stgin "rank=* a.out %r:./a.out"
source /work/system/Env_base
set -x
date
hostname
/opt/FJSVXosPA/bin/xospastop

pwd
#	export HWPC_CHOOSER=FLOPS
#	export HWPC_CHOOSER=VECTOR
#	export HWPC_CHOOSER=FLOPS,VECTOR,INSTRUCTION	# OK
#	export HWPC_CHOOSER=BANDWIDTH
#	export HWPC_CHOOSER=CYCLE,INSTRUCTION

NPROCS=2
export OMP_NUM_THREADS=8
mpiexec -n ${NPROCS} ./stream-K-pmlib.ex

