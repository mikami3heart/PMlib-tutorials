#!/bin/bash
set -x
date
hostname
#	/opt/FJSVXosPA/bin/xospastop

#	PMLIB=${HOME}/pmlib/PMlib-master
#	PMLIB_INCLUDE=-I${PMLIB}/include
#	PMLIB_LIB=${PMLIB}/src/libPM.a
#	PAPI_EXT="${PMLIB}/src_papi_ext/libpapi_ext.a"
PMLIB=${HOME}/pmlib/install_dir
PMLIB_INCLUDE=-I${PMLIB}/include
PMLIB_LIB=${PMLIB}/lib/libPM.a
PAPI_EXT="${PMLIB}/lib/libpapi_ext.a"

#	PAPI_ROOT=/usr
#	PAPI_LIB="$PAPI_ROOT/lib64/libpapi.a $PAPI_ROOT/lib64/libpfm.a"
PAPI_LIB="-lpapi -lpfm"

CXXFLAGS="-Kfast,parallel,openmp ${PMLIB_INCLUDE} ${PAPI_INCLUDE}"
CCFLAGS="-std=c99 -Xg -Kfast,parallel,openmp ${PMLIB_INCLUDE} ${PAPI_INCLUDE}"
LDFLAGS="-Ntl_notrt ${PMLIB_LIB} ${PAPI_LIB} ${PAPI_EXT}"

SRC_DIR=${HOME}/pmlib/scripts
WKDIR=/data/ra000004/a03155/tmp/comp_node
mkdir -p $WKDIR
cd $WKDIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
rm $WKDIR/*
#	cp $SRC_DIR/pmlib_main.cpp main.cpp
#	cp $SRC_DIR/sub_kernel.c sub.c
cp $SRC_DIR/pmlib_stream.cpp main.cpp
cp $SRC_DIR/stream.cpp       sub.cpp

#	mpiFCCpx -c ${CXXFLAGS}  main.cpp sub.cpp
#	mpiFCCpx -o stream-K-pmlib.ex  ${CXXFLAGS}  main.o sub.o ${LDFLAGS}
mpiFCC -c ${CXXFLAGS}  main.cpp sub.cpp
mpiFCC -o stream-K-pmlib.ex  ${CXXFLAGS}  main.o sub.o ${LDFLAGS}
pwd
file stream-K-pmlib.ex
ls -go stream-K-pmlib.ex
exit

#	export HWPC_CHOOSER=FLOPS
#	export HWPC_CHOOSER=VECTOR
#	export HWPC_CHOOSER=FLOPS,VECTOR,INSTRUCTION	# OK
#	export HWPC_CHOOSER=BANDWIDTH
#	export HWPC_CHOOSER=CYCLE,INSTRUCTION

#	NPROCS=2
#	export OMP_NUM_THREADS=4
#	mpirun -np ${NPROCS} ./a.out

