#include <mpi.h>
#include <iostream>
#include <string>
#include <cstdio>
//	#include <cstdlib>
#include <math.h>
#include <omp.h>
#include "papi.h"
#define MATSIZE 1000

struct {
	int nsize;
	float a2[MATSIZE][MATSIZE];
	float b2[MATSIZE][MATSIZE];
	float c2[MATSIZE][MATSIZE];
} matrix;
extern "C" void set_array(), subkerel();
extern "C" int my_papi_bind_start( int *, long long *, int );
//	extern "C" int my_papi_bind_start( void );
extern "C" int my_papi_bind_stop( int *, long long *, int );

struct pmlib_papi {
	int num_events;         // number of PAPI events
	int events[20];         // PAPI events array
	long long values[20];   // PAPI values
};

#ifdef FOR_COMMENTS_ONLY
/* PAPI Hardware info structure */
   typedef struct _papi_hw_info {
      int ncpu;                     /**< Number of CPUs per NUMA Node */
      int threads;                  /**< Number of hdw threads per core */
      int cores;                    /**< Number of cores per socket */
      int sockets;                  /**< Number of sockets */
      int nnodes;                   /**< Total Number of NUMA Nodes */
      int totalcpus;/**< Total number of CPUs in the entire system */
      int vendor;                   /**< Vendor number of CPU */
      char vendor_string[PAPI_MAX_STR_LEN];     /**< Vendor string of CPU */
      int model;                    /**< Model number of CPU */
      char model_string[PAPI_MAX_STR_LEN];      /**< Model string of CPU */
      float revision;               /**< Revision of CPU */
      int cpuid_family;             /**< cpuid family */
      int cpuid_model;              /**< cpuid model */
      int cpuid_stepping;           /**< cpuid stepping */
      int cpu_max_mhz;              /**< Maximum supported CPU speed */
      int cpu_min_mhz;              /**< Minimum supported CPU speed */
      PAPI_mh_info_t mem_hierarchy; /**< PAPI memory heirarchy description */
      int virtualized;              /**< Running in virtual machine */
      char virtual_vendor_string[PAPI_MAX_STR_LEN]; /**< for virtual machine */
      char virtual_vendor_version[PAPI_MAX_STR_LEN]; /**< for virtual machine */
      float mhz;                    /**< Deprecated */
      int clock_mhz;                /**< Deprecated */
      int reserved[8]; /* For future expansion */
   } PAPI_hw_info_t;
#endif

using namespace std;


int main (int argc, char *argv[])
//	int main ()
{

int nsize;
double flop_count;
double tt, t1, t2, t3, t4;
int i, j, loop;
//	FILE *fp;
//	char fn[]="tmp.cio.###";
//	sprintf (fn, "tmp.cio.%3.3d", my_id);
//	fp=fopen(fn,"w+");
float real_time, proc_time, mflops;
float real_time0, proc_time0, mflips;
long long flpops, flpins;
int num_threads;
int retval;
int my_id, npes;

const PAPI_hw_info_t *hwinfo = NULL;

	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &my_id);
	MPI_Comm_size(MPI_COMM_WORLD, &npes);

	num_threads  = omp_get_max_threads();
	if(my_id == 0) {
		printf("<main> npes=%d max_threads=%d\n", npes, num_threads);
		}
	retval = PAPI_library_init( PAPI_VER_CURRENT );
	if(retval != PAPI_VER_CURRENT ) {
		printf("*** <main> <PAPI_library_init> failed for rank=%d\n", my_id);
		}
	retval = PAPI_thread_init( (unsigned long (*)(void)) (omp_get_thread_num) );
	if(retval != PAPI_OK) {
		printf("*** <main> <PAPI_thread_init> failed for rank=%d\n", my_id);
		}
	retval = PAPI_query_event( PAPI_FP_OPS );
	if ( retval != PAPI_OK ) {
		printf ( "*** <main> basic support for PAPI_FP_OPS is missing.\n" );
		}
	hwinfo = PAPI_get_hardware_info();
	if (hwinfo == NULL) {
		printf ( "*** <main> <PAPI_get_hardware_info> failed.\n" );
		}
	printf("%d\n", hwinfo->vendor);
	printf("%s\n", hwinfo->vendor_string);
	printf("%d\n", hwinfo->model);
	printf("%s\n", hwinfo->model_string);
// fx10: Model string and code : Fujitsu SPARC64 IXfx (141)
// vsh:  Model string and code : Intel(R) Xeon(R) CPU E5-2670 0 @ 2.60GHz (45)
// corot: Model string and code : Intel(R) Core(TM) i5-3470S CPU @ 2.90GHz (58)



#pragma omp parallel private(retval)
{
	int i_thread = omp_get_thread_num();
	pmlib_papi papi;
    int ip=0;
	papi.events[ip++] = PAPI_FP_OPS;
	papi.events[ip++] = PAPI_LD_INS;
	papi.events[ip++] = PAPI_SR_INS;
	papi.num_events = ip;

	retval = my_papi_bind_start ( papi.events, papi.values, papi.num_events);

	if ( retval != PAPI_OK ) {
		printf ( "*** <my_papi_bind_start> failed for thread=%d, code=%d\n",
											i_thread, retval );
		}
#pragma omp master
	{
	cout << "papi.num_events=" << papi.num_events << endl;
	printf ( "event # and code:\n");
	for (int i=0; i<papi.num_events; i++)
	{
	printf ( "no. %d, %u\n", i, papi.events[i]);
	}
	}
}

	nsize = matrix.nsize = MATSIZE;

	set_array();

	loop=5;
	for (i=1; i<=loop; i++){
		t1=MPI_Wtime();
		subkerel();
		t2=MPI_Wtime();
		MPI_Barrier(MPI_COMM_WORLD);
		if(my_id == 0) { printf("step %d finished in %f seconds\n", i,(t2-t1));}
	}
	flop_count=pow ((double)nsize, 3.0)*4.0*(float)loop;
	if(my_id == 0) { printf("<main> exact flop count: %15.0f \n", flop_count);}

long long sum=0;
#pragma omp parallel 
{
	pmlib_papi papi;
    int ip=0;
	papi.events[ip++] = PAPI_FP_OPS;
	papi.events[ip++] = PAPI_LD_INS;
	papi.events[ip++] = PAPI_SR_INS;
	papi.num_events = ip;
	int i_thread = omp_get_thread_num();

	retval = my_papi_bind_stop ( papi.events, papi.values, papi.num_events);
	if ( retval != PAPI_OK )
		{
		printf ( "*** Error <my_papi_bind_stop>\n" );
		}

#pragma omp critical
	{
	sum+=papi.values[1];
	printf("thread %d, papi.events[1]=%u, papi.values[1]=%lld, sum=%lld\n ",
					i_thread, papi.events[1], papi.values[1], sum);
	}
}

MPI_Finalize();
return 0;
}

