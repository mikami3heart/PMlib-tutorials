#!/bin/bash
#PJM -N PMLIB-MAKE
#PJM --rsc-list "elapse=1:00:00"
#PJM --rsc-list "node=1"
#PJM --sparam "wait-time=1:00:00"
#	#PJM --mpi "proc=2"
#	#PJM --mpi "rank-map-bychip"
#PJM -j
#PJM -S

source /home/system/Env_base
set -x
date
hostname
/opt/FJSVXosPA/bin/xospastop

INSTALL_DIR=${HOME}/pmlib/install_dir	# /data/mikami/pmlib
SRC_DIR=${HOME}/pmlib/PMlib-master
cd $SRC_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
make distclean

if [[ $HOSTNAME =~ fx02p ]]
then
# login node
./configure CXX=mpiFCCpx CC=mpifccpx FC=mpifrtpx \
   CFLAGS=-Kopenmp,fast  CXXFLAGS='-Kopenmp,fast -DUSE_PAPI' \
   --host=sparc64-unknown-linux-gnu \
   --with-papi=yes \
   --with-example=yes \
   --prefix=${INSTALL_DIR}
   #	--with-papi=/opt/FJSVXosDevkit/sparc64fx/target/usr \

elif [[ $HOSTNAME =~ fx01 ]]
then
# compute node
./configure CXX=mpiFCC CC=mpifcc FC=mpifrt CFLAGS=-Kopenmp,fast  \
   CXXFLAGS='-Kopenmp,fast -DUSE_PAPI' \
   --with-papi=yes --with-example=yes \
   --prefix=${INSTALL_DIR}
fi

# on compute node, the flags should set
#	PAPI_LIB="-L/usr/lib64 -lpapi -lpfm "
#	PAPI_INCLUDE=""

make
make install
