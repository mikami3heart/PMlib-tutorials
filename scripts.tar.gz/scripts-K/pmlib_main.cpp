#include <mpi.h>
#include <stdio.h>
#include <math.h>
#include <omp.h>
#include <PerfMonitor.h>
using namespace pm_lib;
//	char parallel_mode[] = "Serial";
char parallel_mode[] = "Hybrid";
//	char parallel_mode[] = "OpenMP";
//	char parallel_mode[] = "FlatMPI";

#define MATSIZE 1000
int nsize;
struct {
	int nsize;
	float a2[MATSIZE][MATSIZE];
	float b2[MATSIZE][MATSIZE];
	float c2[MATSIZE][MATSIZE];
} matrix;
extern "C" void set_array(), subkerel();
int my_id, npes, num_threads;

PerfMonitor PM;

int main (int argc, char *argv[])
//	int main ()
{

double flop_count;
double tt, t1, t2, t3, t4;
int i, j, loop, num_threads, iret;
enum timing_key {
tm_sec1,
tm_sec2,
tm_END_,
};
float real_time, proc_time, mflops;
long long flpops;

	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &my_id);
	MPI_Comm_size(MPI_COMM_WORLD, &npes);
	num_threads  = omp_get_max_threads();
	nsize=MATSIZE;
	matrix.nsize = nsize;
	if(my_id == 0) {
	fprintf(stderr, "<main> MATSIZE=%d max_threads=%d\n", MATSIZE, num_threads);
	}

PM.setRankInfo(my_id);
	fprintf(stderr, "<main> :: <PM.setRankInfo> finished.\n");
PM.initialize(tm_END_);
	fprintf(stderr, "<main> :: <PM.initialize> finished.\n");
PM.setProperties(tm_sec1, "section1", PerfMonitor::CALC);
//	PM.setProperties(tm_sec2, "SEC2", PerfMonitor::COMM);
//	PM.setProperties(tm_sec3, "SEC3", PerfMonitor::CALC, false);
	fprintf(stderr, "<main> :: <PM.setProperties> finished.\n");
//
num_threads  = omp_get_max_threads();
PM.setParallelMode(parallel_mode, num_threads, npes);
	fprintf(stderr, "<main> :: <PM.setParallelMode> finished.\n");
	fprintf(stderr, "\n<main> starting the measurement\n");
	set_array();

	loop=2;
	for (i=1; i<=loop; i++){
	PM.start(tm_sec1);
		t1=MPI_Wtime();
		subkerel();
		t2=MPI_Wtime();
		MPI_Barrier(MPI_COMM_WORLD);
		if(my_id == 0) { fprintf(stderr, "<main> step %d finished in %f seconds\n", i,t2-t1);}

	flop_count=0.0;
	//	PM.stop (tm_sec1, flop_count, loop);
	PM.stop (tm_sec1);
	}

	flop_count=pow ((double)nsize, 3.0)*4.0*(float)loop;
	if(my_id == 0) { fprintf(stderr, "<main> exact flop count: %15.0f\n\n", flop_count);}

PM.setProperties(tm_sec2, "section2", PerfMonitor::CALC);
PM.start(tm_sec2);
	subkerel();
	flop_count=pow ((double)nsize, 3.0)*4.0;
PM.stop (tm_sec2, flop_count, 1);
PM.gather();
PM.print(stdout, "QQQ", "RRR");
PM.printDetail(stdout);

MPI_Finalize();
return 0;
}

