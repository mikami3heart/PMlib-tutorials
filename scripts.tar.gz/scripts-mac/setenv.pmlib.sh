PMLIB_ROOT=${HOME}/tmp
export PMLIB_INCLUDES="-I${PMLIB_ROOT}/include"
export PMLIB_LDFLAGS="-L${PMLIB_ROOT}/lib -lPM"

