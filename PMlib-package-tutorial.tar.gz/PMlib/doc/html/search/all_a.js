var searchData=
[
  ['researved_5fnwatch',['researved_nWatch',['../classpm__lib_1_1_perf_monitor.html#ad1a62464d24709ab73ac4666fa5e798d',1,'pm_lib::PerfMonitor']]]
];
