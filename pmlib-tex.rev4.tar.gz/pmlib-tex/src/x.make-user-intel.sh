#!/bin/bash

#	module load intel
INTEL_DIR=/usr/local/intel/composer_xe_2013
source ${INTEL_DIR}/bin/compilervars.sh intel64

#	module load impi
export I_MPI_ROOT=/usr/local/intel/impi/4.1.0.024
source ${I_MPI_ROOT}/bin64/mpivars.sh
export I_MPI_F90=ifort 
export I_MPI_F77=ifort 
export I_MPI_CC=icc 
export I_MPI_CXX=icpc 
export  I_HYDRA_BOOTSTRAP=ssh
export  I_HYDRA_BOOTSTRAP_EXEC=/usr/bin/ssh


#	module load papi/intel
PAPI_ROOT=/usr/local/papi/papi-5.3.2/intel
PAPI_DIR=${PAPI_ROOT}
export LDFLAGS="-L${PAPI_ROOT}/lib -lpapi -lpfm"
export INCLUDES="-I{PAPI_ROOT}/include"
export LD_LIBRARY_PATH=${PAPI_ROOT}/lib:${LD_LIBRARY_PATH}


set -x
PMLIB_ROOT=${HOME}/pmlib/install_develop

SRC_DIR=${HOME}/pmlib/PMlib/example/test1
WKDIR=/media/dali/data1/mikami/check_user
mkdir -p $WKDIR
cd $WKDIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
rm $WKDIR/*
cp $SRC_DIR/pmlib_test.cpp  main.cpp

CXXFLAGS="-O3 -openmp -DUSE_PAPI "
PMLIB_INCLUDES="-I${PMLIB_ROOT}/include "
PAPI_INCLUDES="-I${PAPI_ROOT}/include "
INCLUDES="${PMLIB_INCLUDES} ${PAPI_INCLUDES}"

PMLIB_LDFLAGS="-L${PMLIB_ROOT}/lib -lPMmpi -lpapi_ext "
PAPI_LDFLAGS="-L${PAPI_ROOT}/lib -lpapi -lpfm "
LDFLAGS="${PMLIB_LDFLAGS} ${PAPI_LDFLAGS}"

mpicxx ${CXXFLAGS} ${INCLUDES} -o main.ex main.cpp ${LDFLAGS}

NPROCS=3
export OMP_NUM_THREADS=2
export HWPC_CHOOSER=FLOPS
mpirun -np ${NPROCS} ./main.ex
mpiexec.hydra -np ${NPROCS} ./main.ex
exit
