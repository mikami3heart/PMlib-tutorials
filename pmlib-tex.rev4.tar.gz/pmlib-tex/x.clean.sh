#! /bin/bash
set -x
rm -f *.aux *.bbl *.blg *.dvi *.fdb_latexmk *.fls *.idx *.ilg *.log *.out *.pdf *.toc

