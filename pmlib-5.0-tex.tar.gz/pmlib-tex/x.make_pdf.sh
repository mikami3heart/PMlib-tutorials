#! /bin/bash
set -x
HERE=${HOME}/Desktop/Programming/Perf_tools/AICS-PMlib/user_guide/pmlib-tex
cd ${HERE}
if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi

rm -f *.aux *.bbl *.blg *.dvi *.fdb_latexmk *.fls *.idx *.ilg *.log *.out *.pdf *.toc

export TEXINPUTS='.//;'

platex PMlib #	2>&1 >/dev/null
pbibtex PMlib 2>&1 >/dev/null
platex PMlib 2>&1 >/dev/null
mendex PMlib.idx 2>&1 >/dev/null
#	mendex -s myindex PMlib.idx 2>&1 >/dev/null
#	dvipdfmx -v PMlib 2>&1 >/dev/null
dvipdfmx PMlib 2>&1 >/dev/null
pwd

open PMlib.pdf
