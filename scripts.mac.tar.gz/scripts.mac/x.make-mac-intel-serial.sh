#!/bin/bash
date
hostname
source /opt/intel/bin/compilervars.sh intel64
set -x
INSTALL_DIR=${HOME}/Desktop/Programming/Perf_tools/AICS-PMlib/install_mac

SRC_DIR=${HOME}/Desktop/Programming/Perf_tools/AICS-PMlib/pmlib/PMlib
#	SRC_DIR=${HOME}/Desktop/Git_Repos/PMlib
BUILD_DIR=${SRC_DIR}/BUILD_DIR

cd $BUILD_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
make distclean >/dev/null 2>&1

CFLAGS="-std=c99 -openmp"
FCFLAGS="-fpp -openmp"
CXXFLAGS="-openmp"

../configure \
	CXX=icpc CC=icc FC=ifort \
	CFLAGS="${CFLAGS}" CXXFLAGS="${CXXFLAGS}" FCFLAGS="${FCFLAGS}" \
	--prefix=${INSTALL_DIR} \
	--with-comp=INTEL \
	--with-papi=none --with-example=yes  >/dev/null 2>&1

make
example/test1/test1
example/test2/test2
example/test3/test3
example/test4/test4
sleep 5

make install # may be done by root
if [ $? != 0 ] ; then echo '@@@ installation error @@@'; exit; fi

