#!/bin/bash
set -x
date
hostname
#
INSTALL_DIR=${HOME}/Desktop/Programming/Perf_tools/AICS-PMlib/install_mac

#SRC_DIR=${HOME}/Desktop/Git_Repos/PMlib
SRC_DIR=${HOME}/Desktop/Programming/Perf_tools/AICS-PMlib/pmlib/PMlib

BUILD_DIR=${SRC_DIR}/BUILD_DIR
cd $BUILD_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi
make distclean >/dev/null 2>&1

FCFLAGS="-cpp"
CFLAGS=""
CXXFLAGS=""

../configure \
	CXX=clang++ CC=cc FC=gfortran \
	CFLAGS="${CFLAGS}" CXXFLAGS="${CXXFLAGS}" FCFLAGS="${FCFLAGS}" \
	--prefix=${INSTALL_DIR} \
	--with-papi=none \
	--with-example=yes

make
sleep 2
#	make install # may be done by root
#	if [ $? != 0 ] ; then echo '@@@ installation error @@@'; exit; fi
#	exit

sleep 2
example/test1/test1
sleep 2
example/test2/test2
sleep 2
example/test3/test3
sleep 2
example/test4/test4

