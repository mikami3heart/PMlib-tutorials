#!/bin/bash
#	module load intel impi papi/intel
SRC_DIR=${HOME}/pmlib/PMlib-master
cd $SRC_DIR; if [ $? != 0 ] ; then echo '@@@ Directory error @@@'; exit; fi

set -x
vi configure.ac
aclocal
autoheader
automake -a -c
autoconf
./configure CXX=g++ CC=gcc --prefix=${HOME}/tmp
make
make install

make distclean
./configure CXX=mpic++ CC=mpicc --prefix=${HOME}/tmp
make
make install


